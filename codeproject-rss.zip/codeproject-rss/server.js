var file = {
	stream: require('fs'),
	path: __dirname + '/' + 'message'
}

file.stream.readFile('.rss', function(error, buffer) {
	var reader = new (require('string_decoder')).StringDecoder('UTF8')
	var readings = reader.write(buffer)
	
	file.stream.stat(file.path, function(error, stats) {
		if(error) { return }

		if(stats.isFile()) {
			file.stream.unlinkSync(file.path)
		}
	})
	
	var content = new Uint8Array(Buffer.from(readings))
	
	// BUG: Silent fail on one run
	file.stream.writeFile('message', content, function(error) {})
})

return

var http = require('http')

var body = {
	content: '<h1>hello</h1>',
	type: 'text/html'
}

body.size = Buffer.byteLength(body.content)

var headers = {
	'Content-Length': body.size,
	'Content-Type': body.type
}

var web = {
	server: '',
	port: 3000,
	status: {
		OK: 200
	}
}

web.server = http.createServer(function(request, response) {
	var page = body.content
	response.writeHead(web.status.OK, headers).end(page)
})

web.server.listen(web.port)